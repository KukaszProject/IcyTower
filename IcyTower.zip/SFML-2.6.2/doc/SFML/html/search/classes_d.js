var searchData=
[
  ['noncopyable_0',['NonCopyable',['../classsf_1_1NonCopyable.html',1,'sf']]]
];
